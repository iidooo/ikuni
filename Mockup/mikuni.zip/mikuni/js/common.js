/**
 * Created by Ethan on 16/4/6.
 */
//var clientURL = "http://localhost:63342/mikuni";
var clientURL = "http://www.iidooo.com/mikuni";

