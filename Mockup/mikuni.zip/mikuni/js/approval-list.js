/**
 * Created by Ethan on 16/4/30.
 */
$(function () {

    $("#tbodyApprovalList tr").click(function(){
        location.href = "approval-detail.html";
    });

    console.log()
});