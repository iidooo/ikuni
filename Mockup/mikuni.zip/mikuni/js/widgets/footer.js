/**
 * Created by Ethan on 16/4/6.
 */
$(function(){
    $('footer').load(clientURL + '/widgets/footer.html');
});