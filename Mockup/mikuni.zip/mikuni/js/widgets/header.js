/**
 * Created by Ethan on 16/4/6.
 */

$(function () {
    $('header').load(clientURL + '/widgets/header.html');


});